const jwt = require("jsonwebtoken")
const Joi = require("joi")
const { neon } = require("@neondatabase/serverless")

const sql = neon(process.env.DATABASE_URL)

function authenticateToken(req) {
  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1]

  if (!token) {
    throw new Error("Access token required")
  }

  try {
    const user = jwt.verify(token, process.env.JWT_SECRET || "your-secret-key")
    return user
  } catch (err) {
    throw new Error("Invalid or expired token")
  }
}

const createPickupSchema = Joi.object({
  type: Joi.string().valid("Plastic", "Organic", "E-waste").required(),
  locationLat: Joi.number().min(-90).max(90),
  locationLng: Joi.number().min(-180).max(180),
  locationAddress: Joi.string().max(500),
  notes: Joi.string().max(1000),
  scheduledAt: Joi.date().iso(),
})

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader("Access-Control-Allow-Credentials", true)
  res.setHeader("Access-Control-Allow-Origin", "*")
  res.setHeader("Access-Control-Allow-Methods", "GET,OPTIONS,PATCH,DELETE,POST,PUT")
  res.setHeader(
    "Access-Control-Allow-Headers",
    "X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization",
  )

  if (req.method === "OPTIONS") {
    res.status(200).end()
    return
  }

  try {
    const user = authenticateToken(req)

    if (req.method === "POST") {
      // Create pickup request
      const { error, value } = createPickupSchema.validate(req.body)
      if (error) {
        return res.status(400).json({ error: error.details[0].message })
      }

      const { type, locationLat, locationLng, locationAddress, notes, scheduledAt } = value

      const result = await sql`
        INSERT INTO pickup_requests (user_id, type, location_lat, location_lng, location_address, notes, scheduled_at)
        VALUES (${user.userId}, ${type}, ${locationLat || null}, ${locationLng || null}, ${locationAddress || null}, ${notes || null}, ${scheduledAt || null})
        RETURNING *
      `

      const pickup = result[0]

      res.status(201).json({
        message: "Pickup request created successfully",
        pickup: {
          id: pickup.id,
          type: pickup.type,
          status: pickup.status,
          locationLat: pickup.location_lat,
          locationLng: pickup.location_lng,
          locationAddress: pickup.location_address,
          notes: pickup.notes,
          scheduledAt: pickup.scheduled_at,
          createdAt: pickup.created_at,
        },
      })
    } else if (req.method === "GET") {
      // Get user's pickup requests
      const { status, limit = 20, offset = 0 } = req.query

      let query = sql`
        SELECT pr.*, c.name as collector_name
        FROM pickup_requests pr
        LEFT JOIN users c ON pr.collector_id = c.id
        WHERE pr.user_id = ${user.userId}
      `

      if (status) {
        query = sql`
          SELECT pr.*, c.name as collector_name
          FROM pickup_requests pr
          LEFT JOIN users c ON pr.collector_id = c.id
          WHERE pr.user_id = ${user.userId} AND pr.status = ${status}
        `
      }

      const result = await query

      const pickups = result.map((pickup) => ({
        id: pickup.id,
        type: pickup.type,
        status: pickup.status,
        weight: pickup.weight ? Number.parseFloat(pickup.weight) : null,
        pointsEarned: pickup.points_earned,
        locationLat: pickup.location_lat,
        locationLng: pickup.location_lng,
        locationAddress: pickup.location_address,
        notes: pickup.notes,
        collectorName: pickup.collector_name,
        scheduledAt: pickup.scheduled_at,
        collectedAt: pickup.collected_at,
        createdAt: pickup.created_at,
      }))

      res.json({ pickups })
    } else {
      res.status(405).json({ error: "Method not allowed" })
    }
  } catch (error) {
    console.error("Pickups error:", error)
    if (error.message === "Access token required" || error.message === "Invalid or expired token") {
      return res.status(401).json({ error: error.message })
    }
    res.status(500).json({ error: "Internal server error" })
  }
}
